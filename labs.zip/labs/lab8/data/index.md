Data:

- [single.csv](single.csv)
- [mixture.csv](mixture.csv)

Code: 

- [fittingfunctions.R](fittingfunctions.R)
